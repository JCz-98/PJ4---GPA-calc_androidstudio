package mchehab.com.java.click_listeners;

import mchehab.com.java.Person;

public interface OnDeleteListener {
    public void deleteItem(Person person);
}

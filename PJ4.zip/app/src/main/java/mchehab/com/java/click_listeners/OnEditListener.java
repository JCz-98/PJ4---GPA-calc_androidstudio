package mchehab.com.java.click_listeners;

import mchehab.com.java.Person;

public interface OnEditListener {
    public void editItem(Person person, int index);
}

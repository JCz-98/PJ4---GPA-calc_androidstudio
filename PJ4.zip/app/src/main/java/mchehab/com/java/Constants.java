package mchehab.com.java;

public class Constants
{
    public static String PERSON_INTENT_EDIT = "isEdit";
    public static String PERSON_INTENT_OBJECT = "person";
    public static String PERSON_INTENT_INDEX = "index";
}

package mchehab.com.java;

import java.util.ArrayList;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class activity_gpa extends AppCompatActivity
{
    private ArrayList<String> grades;
    private ArrayList<String> credits;

    private TextView gpaText;

    private final int[] letterGrade = {4,3,2,1,0};
    private double gpaTotal;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_gpa);

        gpaText = findViewById(R.id.show_count);

        grades = getIntent().getStringArrayListExtra("grades");
        credits = getIntent().getStringArrayListExtra("credits");

        double sum = 0;
        double sumCredits = 0;

        //System.out.println(grades.size());
        for(int i = 0; i < grades.size(); i++){

            //System.out.println(grades.get(i));
            //System.out.println(credits.get(i));
            if (grades.get(i).equals("A"))
                sum+= letterGrade[0] * Integer.parseInt(credits.get(i));
            else if (grades.get(i).equals("B"))
                sum+= letterGrade[1] * Integer.parseInt(credits.get(i));
            else if (grades.get(i).equals("C"))
                sum+= letterGrade[2] * Integer.parseInt(credits.get(i));
            else if (grades.get(i).equals("D"))
                sum+= letterGrade[3] * Integer.parseInt(credits.get(i));
            else if (grades.get(i).equals("F"))
                sum+= letterGrade[4] * Integer.parseInt(credits.get(i));

            sumCredits+= Integer.parseInt(credits.get(i));

        }

        gpaTotal = sum/sumCredits;

        gpaText.setText(String.format("%.2f", gpaTotal));

    }
}

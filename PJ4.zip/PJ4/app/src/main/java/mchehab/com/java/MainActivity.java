package mchehab.com.java;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import mchehab.com.java.click_listeners.OnDeleteListener;
import mchehab.com.java.click_listeners.OnEditListener;

/*Autores:
Jonathan Cazco, Erick Ñauñay

Proyecto adaptado desde https://mobiledevhub.com/2018/09/15/android-add-remove-and-edit-recyclerview-items/
    Autor: MCHEHAB
 */
public class MainActivity extends AppCompatActivity implements OnEditListener, OnDeleteListener
{

    private FloatingActionButton floatingActionButton;
    private RecyclerView recyclerView;

    private PersonAdapter personAdapter;
    private List<Person> listPerson;

    private final int REQUEST_CODE_EDIT = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listPerson = new ArrayList<>();
        for(int i=1;i<=5;i++)
        {
            listPerson.add(new Person("CMP" + (100*i+i), "Programacion " + (i), "3" , "C"));
        }

        listPerson.add(new Person("CMP 500", "P1", "5", "A"));


        floatingActionButton = findViewById(R.id.floatingActionButton);
        recyclerView = findViewById(R.id.recyclerView);

        personAdapter = new PersonAdapter(listPerson, this, this);
        recyclerView.setAdapter(personAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,
         false));
        setFloatingActionButtonListener();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
        //checa como manejar los eventos en el tutorial Android fundamentals 04.3: Menus and pickers
    }

    private void setFloatingActionButtonListener()
    {
        floatingActionButton.setOnClickListener(e ->
        {
            Intent intent = new Intent(this, EditActivity.class);
            intent.putExtra(Constants.PERSON_INTENT_EDIT, false);
            startActivityForResult(intent, REQUEST_CODE_EDIT);
        });
    }

    @Override
    public void deleteItem(Person person)
    {
        listPerson.remove(person);
        personAdapter.notifyDataSetChanged();
    }

    @Override
    public void editItem(Person person, int index)
    {
        Intent intent = new Intent(this, EditActivity.class);
        intent.putExtra(Constants.PERSON_INTENT_EDIT, true);
        intent.putExtra(Constants.PERSON_INTENT_INDEX, index);
        intent.putExtra(Constants.PERSON_INTENT_OBJECT, person);
        startActivityForResult(intent, REQUEST_CODE_EDIT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE_EDIT)
        {
            if(resultCode == RESULT_OK)
            {
                if(data == null)
                {
                    return;
                }
                boolean isEdit = data.getBooleanExtra(Constants.PERSON_INTENT_EDIT, false);
                Person person = data.getParcelableExtra(Constants.PERSON_INTENT_OBJECT);
                if(isEdit)
                {
                    int index = data.getIntExtra(Constants.PERSON_INTENT_INDEX, -1);
                    if(index == -1)
                    {
                        return;
                    }
                    listPerson.set(index, person);
                    personAdapter.notifyDataSetChanged();
                }
                else {
                    //parse duplicated class codes

                    String incomingCode = person.getFirstName();
                    boolean search = false;
                    for(Person clase : listPerson)
                    {
                        String onlistCode = clase.getFirstName();

                        if(incomingCode.equals(onlistCode))
                        {
                            search = true;
                            Log.v("SEARCH", "Item en lista");
                            break;
                        }

                    }

                    if(search == false)
                    {
                        Log.v("SEARCH", "Item no en lista");
                        listPerson.add(person);
                        personAdapter.notifyDataSetChanged();
                    }
                    else
                    {
                        Snackbar adv = Snackbar.make(this.recyclerView, "Item already ON LIST!", Snackbar.LENGTH_LONG);
                        adv.show();
                    }

                }
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        int id = item.getItemId();

        if (id == R.id.action_sort) {
            sortClassby_Nota();
        }
        else if (id == R.id.action_erase){
            clearData();
        }

        return super.onOptionsItemSelected(item);

    }

    public void sortClassby_Nota()
    {
        List<Person> sortedArray = listPerson.stream()
                .sorted(Comparator.comparing(Person::getNota))
                .collect(Collectors.toList());

        listPerson.clear();
        recyclerView.getAdapter().notifyDataSetChanged();
        listPerson.addAll(sortedArray);
        recyclerView.getAdapter().notifyDataSetChanged();

    }

    public void clearData(){
        listPerson.clear();
        recyclerView.getAdapter().notifyDataSetChanged();
    }
    //intento, no se actualiza adapter y funciones dejan de actuar/ actuan mal
    //solucion --> implementar independiente en menu con opcion ordenar

    public void calc_GPA(View view)
    {
        Intent intent = new Intent(this, activity_gpa.class);

        ArrayList<String> grades = new ArrayList<>(listPerson.size());
        ArrayList<String> credits = new ArrayList<>(listPerson.size());

         for (Person course: listPerson){
             grades.add(course.getNota());
             credits.add(course.getCreditos());
        }

        intent.putStringArrayListExtra("grades", grades);
        intent.putStringArrayListExtra("credits", credits);

        startActivity(intent);


        //pasate una lista de las calificaciones, espero que esto sirva
        // https://stackoverflow.com/questions/6543811/intent-putextra-list
    }

}
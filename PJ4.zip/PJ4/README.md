This is a simple repo that demonstrates how to add, edit, and remove items in a RecyclerView.
The project contains two modules:
* app: Kotlin version of the code
* java: Java version of the code.

A thorough explanation for the code can be found in the post [here](http://mobiledevhub.com/2018/09/15/android-add-remove-and-edit-recyclerview-items/).  
Feel free to contact me in case you have any suggestions/comments/feedback for improvement.
